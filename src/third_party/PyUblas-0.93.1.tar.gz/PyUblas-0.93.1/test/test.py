#! /usr/bin/python
import pyublas.test
import unittest
unittest.main(pyublas.test)
